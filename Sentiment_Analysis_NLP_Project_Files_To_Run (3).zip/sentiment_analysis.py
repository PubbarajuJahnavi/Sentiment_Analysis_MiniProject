# Sentiment Analysis Using NLP (Rule-Based)
# Beginner-friendly project: no external libraries required.

import re

POSITIVE_WORDS = {
    "good", "great", "excellent", "happy", "love", "awesome",
    "amazing", "wonderful", "best", "beautiful", "nice", "fantastic",
    "enjoy", "enjoyed", "perfect", "brilliant", "success"
}
NEGATIVE_WORDS = {
    "bad", "worst", "poor", "sad", "hate", "terrible", "awful",
    "boring", "angry", "disappointing", "dislike", "failed",
    "horrible", "ugly", "problem"
}
NEGATIONS = {"not", "no", "never", "isn't", "wasn't", "don't", "doesn't", "didn't"}

def analyze_sentiment(sentence):
    # Normalize text and extract words (including contractions)
    words = re.findall(r"[a-z]+(?:'[a-z]+)?", sentence.lower())
    positive = 0
    negative = 0

    for i, word in enumerate(words):
        # A simple negation rule: reverse the sentiment of the next sentiment word.
        negated = i > 0 and words[i - 1] in NEGATIONS
        if word in POSITIVE_WORDS:
            if negated:
                negative += 1
            else:
                positive += 1
        elif word in NEGATIVE_WORDS:
            if negated:
                positive += 1
            else:
                negative += 1

    if positive > negative:
        label = "Positive"
    elif negative > positive:
        label = "Negative"
    else:
        label = "Neutral"

    return positive, negative, label

def main():
    print("=" * 48)
    print("       NLP SENTIMENT ANALYSIS SYSTEM")
    print("=" * 48)
    print("Type 'exit' to close the program.\\n")

    while True:
        sentence = input("Enter a review/sentence: ").strip()
        if sentence.lower() == "exit":
            print("Thank you for using the Sentiment Analysis System!")
            break
        if not sentence:
            print("Please enter a sentence.\\n")
            continue

        pos, neg, result = analyze_sentiment(sentence)
        print("\\n----- Analysis Result -----")
        print("Positive score :", pos)
        print("Negative score :", neg)
        print("Sentiment      :", result)
        print("--------------------------\\n")

if __name__ == "__main__":
    main()
