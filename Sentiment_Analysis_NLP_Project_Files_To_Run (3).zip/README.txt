SENTIMENT ANALYSIS USING NLP — PROJECT FILES

Files:
1. sentiment_analysis.py — working Python program
2. README.txt — run instructions
3. Project_Report.docx — editable project report

How to run:
- Install Python 3.
- Open this folder in VS Code or PyCharm.
- Open a terminal in this folder.
- Run: python sentiment_analysis.py
- Enter a review, for example: "This movie is amazing and excellent"
- Type exit to stop.

This is a rule-based sentiment classifier using a small sentiment-word dictionary.
It is a simple educational project and is not a trained machine-learning model.
Please add your name, register number, college, department, guide name, and actual screenshots/results before submission.
